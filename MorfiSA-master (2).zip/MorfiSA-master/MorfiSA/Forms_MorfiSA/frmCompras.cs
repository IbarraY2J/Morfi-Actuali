﻿using Clases_MorfiSA;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Forms_MorfiSA
{
    public partial class frmCompras : Form
    {
        public frmCompras()
        {
            InitializeComponent();
        }

        private void frmCompras_Load(object sender, EventArgs e)
        {
            cboIngredientes.DataSource = Ingrediente.ObtenerListaIngredientes();

            ActualizarListaCabeceras();
        }

        private void ActualizarListaCabeceras()
        {
            dgvComprasCabecera.DataSource = null;
            dgvComprasCabecera.DataSource = Compra.ObtenerListaCabecerasCompra();
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            
            try
            {
                Compra.GenerarNuevaCompra(dtpFecha.Value, txtComprobante.Text.Trim());
                
                MessageBox.Show("Se agrego la Cabecera (Factura) de Compra, ahora puede agregar el detalle al mismo!");

                ActualizarListaCabeceras();

                LimpiarControles();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void LimpiarControles()
        {
            txtComprobante.Text = "";
        }

        private void btnAgregarIngredienteCompra_Click(object sender, EventArgs e)
        {
            if (dgvComprasCabecera.SelectedRows.Count > 0)
            {
                int IdCompra = int.Parse(dgvComprasCabecera.SelectedRows[0].Cells[0].Value.ToString());
                Ingrediente elIngredienteSeleccionadodelCombo = (Ingrediente)cboIngredientes.SelectedItem;

                DetalleCompra.RegistrarDetalleCompra(IdCompra, elIngredienteSeleccionadodelCombo.IDIngrediente, int.Parse(nudCantidad.Value.ToString()));

                
                int CantidadActualExistenciaIngrediente = elIngredienteSeleccionadodelCombo.CantidadExistencia;
                int ExistenciaActualizadaPostCompra = CantidadActualExistenciaIngrediente + int.Parse(nudCantidad.Value.ToString());

                Ingrediente.ActualizarStock(elIngredienteSeleccionadodelCombo.IDIngrediente, ExistenciaActualizadaPostCompra);

                ActualizarListaDetalles(IdCompra);

                MessageBox.Show("Detalle Registrado y Stock del Ingrediente Actualizado satisfactoriamente!");
            }
            else
                MessageBox.Show("Debe seleccionar la compra de la grilla, a la cual asociar los ingredientes comprados!");
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (dgvComprasDetalles.SelectedRows.Count > 0)
            {
                int IdCompra = int.Parse(dgvComprasDetalles.SelectedRows[0].Cells[0].Value.ToString());
                int IdIngrediente = int.Parse(dgvComprasDetalles.SelectedRows[0].Cells[1].Value.ToString());
                int Cantidad = int.Parse(dgvComprasDetalles.SelectedRows[0].Cells[2].Value.ToString());

                DetalleCompra.EliminarDetalleCompra(IdCompra, IdIngrediente);

                                
                Ingrediente.RestarDelStockActualIngrediente(IdIngrediente, Cantidad);

                ActualizarListaDetalles(IdCompra);

                MessageBox.Show("Se ha eliminado el ingrediente de la Compra y se actualizo el stock anterior a la compra!");

                LimpiarControles();
            }
            else
                MessageBox.Show("Favor, elija el Plato/ingrediente de la grilla que desea eliminar!");
        }

        private void ActualizarListaDetalles(int IdCompra)
        {
            dgvComprasDetalles.DataSource = null;
            dgvComprasDetalles.DataSource = DetalleCompra.ObtenerListaDetalleCompra(IdCompra);
        }

        private void dgvComprasCabecera_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvComprasCabecera.SelectedRows.Count > 0)
            {
                int IdCompra = int.Parse(dgvComprasCabecera.SelectedRows[0].Cells[0].Value.ToString());

                ActualizarListaDetalles(IdCompra);
            }
        }
    }
}
