﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Forms_MorfiSA
{
    public partial class frmMenu : Form
    {
        public frmMenu()
        {
            InitializeComponent();
        }

        private void mantClientesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmCliente formularioClientes = new frmCliente();
            formularioClientes.ShowDialog();
        }

        private void platosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmPlato formularioPlatos = new frmPlato();
            formularioPlatos.ShowDialog();
        }

        private void ingredientesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmIngrediente formularioIng = new frmIngrediente();
            formularioIng.ShowDialog();
        }

        private void recetasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmReceta formularioDeRecetas = new frmReceta();
            formularioDeRecetas.ShowDialog();
        }

        private void registroDeComprasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmCompras formularioDeCompras = new frmCompras();
            formularioDeCompras.ShowDialog();
        }

        private void cargaDePedidosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmPedidos formularioPedidos = new frmPedidos();
            formularioPedidos.ShowDialog();
        }

        private void calculoRapidoProvisionesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmCalculadora formularioCalc = new frmCalculadora();
            formularioCalc.ShowDialog();
        }

        private void acercaDeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmAcercaDe formularioAcercade = new frmAcercaDe();
            formularioAcercade.ShowDialog();
        }
    }
}
