﻿using Clases_MorfiSA;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Forms_MorfiSA
{
    public partial class frmIngrediente : Form
    {
        public frmIngrediente()
        {
            InitializeComponent();
        }

        private void frmIngrediente_Load(object sender, EventArgs e)
        {
            ActualizarListaIngredientes();
        }

        private void ActualizarListaIngredientes()
        {
            dgvIngredientes.DataSource = null;
            dgvIngredientes.DataSource = Ingrediente.ObtenerListaIngredientes();
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            
            try
            {
                Ingrediente.AgregarIngrediente(txtNombreIngrediente.Text.Trim());
                

                MessageBox.Show("Ingrediente Agregado!");

                ActualizarListaIngredientes();

                LimpiarControles();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void LimpiarControles()
        {
            txtNombreIngrediente.Text = string.Empty;
            txtNombreIngrediente.Focus();           
        }

        private void btnModificar_Click(object sender, EventArgs e)
        {
            if (dgvIngredientes.SelectedRows.Count > 0)
            {
                
                Ingrediente ing = (Ingrediente)dgvIngredientes.SelectedRows[0].DataBoundItem;

                Ingrediente.ModificarPlato(ing.IDIngrediente, txtNombreIngrediente.Text.Trim());

                ActualizarListaIngredientes();

                MessageBox.Show("Ingrediente Modificado!");

                LimpiarControles();
            }
            else
            {
                MessageBox.Show("Debe seleccionar el Ingrediente a modificar!");
            }
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (dgvIngredientes.SelectedRows.Count > 0)
            {
                Ingrediente ing = (Ingrediente)dgvIngredientes.SelectedRows[0].DataBoundItem;

                Ingrediente.EliminarIngrediente(ing.IDIngrediente);

                ActualizarListaIngredientes();

                MessageBox.Show("Ingrediente Eliminado!");

                LimpiarControles();
            }
            else
                MessageBox.Show("Favor, elija el Plato de la lista que desea eliminar!");
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            LimpiarControles();
        }

        private void dgvIngredientes_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvIngredientes.SelectedRows.Count > 0)
            {
                Ingrediente ing = (Ingrediente)dgvIngredientes.SelectedRows[0].DataBoundItem;
                txtNombreIngrediente.Text = ing.Nombre;
            }
        }
    }
}
