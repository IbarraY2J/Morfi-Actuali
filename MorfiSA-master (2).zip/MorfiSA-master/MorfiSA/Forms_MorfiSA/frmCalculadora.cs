﻿using Clases_MorfiSA;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Forms_MorfiSA
{
    public partial class frmCalculadora : Form
    {
        public frmCalculadora()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            Plato elPlatoSeleccionadodelCombo = (Plato)cboPlatos.SelectedItem;
            CalculoIngrediente CalculoParaCadaIngrediente;
            List<CalculoIngrediente> listaCalculoTodosLosIngredientesDelPlato = new List<CalculoIngrediente>();

            
            List<Receta> listaIngredientesPorPlato = Receta.ObtenerListaIngredientesPorPlato(elPlatoSeleccionadodelCombo);

            
            foreach (Receta r in listaIngredientesPorPlato)
            {
                
                int CalculoCantidadNecesaria = int.Parse(nudCantidad.Value.ToString()) * r.CantidadNecesariaParaUnPlato;

                
                int CalculoDiferencia = r.elIngrediente.CantidadExistencia - CalculoCantidadNecesaria;

                
                CalculoParaCadaIngrediente = new CalculoIngrediente();
                CalculoParaCadaIngrediente.NombreIngrediente = r.elIngrediente.Nombre;
                CalculoParaCadaIngrediente.CantidadExistencia = r.elIngrediente.CantidadExistencia;
                CalculoParaCadaIngrediente.CantidadNecesaria = CalculoCantidadNecesaria;
                CalculoParaCadaIngrediente.Diferencia = CalculoDiferencia;

                listaCalculoTodosLosIngredientesDelPlato.Add(CalculoParaCadaIngrediente);
            }

            dgvCalculos.DataSource = null;
            dgvCalculos.DataSource = listaCalculoTodosLosIngredientesDelPlato;
        }

        private void frmCalculadora_Load(object sender, EventArgs e)
        {
            cboPlatos.DataSource = Plato.ObtenerListaPlatos();
        }
    }
}
