﻿using Clases_MorfiSA;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Forms_MorfiSA
{
    public partial class frmPlato : Form
    {
        public frmPlato()
        {
            InitializeComponent();
        }

        private void frmPlato_Load(object sender, EventArgs e)
        {
            ActualizarListaCompletaPlatos();
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            
            try
            {
                Plato.AgregarPlato(txtNombrePlato.Text.Trim());

                MessageBox.Show("Plato Agregado!");

                ActualizarListaCompletaPlatos();

                LimpiarControles();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void LimpiarControles()
        {
            txtNombrePlato.Text = "";
            txtNombrePlato.Focus();
        }

        private void ActualizarListaCompletaPlatos()
        {
            lstPlatos.DataSource = null;
            lstPlatos.DataSource = Plato.ObtenerListaPlatos();
        }

        private void btnModificar_Click(object sender, EventArgs e)
        {
            if (lstPlatos.SelectedItem != null)
            {
                
                Plato pla = (Plato)lstPlatos.SelectedItem;

                Plato.ModificarPlato(pla.IDPlato, txtNombrePlato.Text.Trim());

                ActualizarListaPlatos();

                MessageBox.Show("Plato Modificado!");

                LimpiarControles();
            }
            else
            {
                MessageBox.Show("Debe seleccionar el Plato a modificar!");
            }
        }

        private void ActualizarListaPlatos()
        {
            lstPlatos.DataSource = null;
            lstPlatos.DataSource = Plato.ObtenerListaPlatos();
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (lstPlatos.SelectedItem != null)
            {
                Plato PlatoSeleccionado = (Plato)lstPlatos.SelectedItem;

                Plato.EliminarPlato(PlatoSeleccionado.IDPlato);

                ActualizarListaCompletaPlatos();

                MessageBox.Show("Plato Eliminado!");

                LimpiarControles();
            }
            else
                MessageBox.Show("Favor, elija el Plato de la lista que desea eliminar!");
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            LimpiarControles();
        }

        private void lstPlatos_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstPlatos.SelectedItem != null)
            {
                Plato platoSeleccionado = (Plato)lstPlatos.SelectedItem;
                txtNombrePlato.Text = platoSeleccionado.NombrePlato;                
            }
        }
    }
}
