﻿using Clases_MorfiSA;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Forms_MorfiSA
{
    public partial class frmReceta : Form
    {
        public frmReceta()
        {
            InitializeComponent();
        }

        private void frmReceta_Load(object sender, EventArgs e)
        {
            cboPlatos.DataSource = Plato.ObtenerListaPlatos();
            cboIngredientes.DataSource = Ingrediente.ObtenerListaIngredientes();

            ActualizarListaRecetas();
        }

        private void ActualizarListaRecetas()
        {
            dgvRecetas.DataSource = null;
            dgvRecetas.DataSource = Receta.ObtenerListaRecetas();
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            
            try
            {
                Plato elPlatoSeleccionadodelCombo = (Plato)cboPlatos.SelectedItem;
                Ingrediente elIngredienteSeleccionadodelCombo = (Ingrediente)cboIngredientes.SelectedItem;
                int Cantidad = int.Parse(nudCantidad.Value.ToString());

                Receta.AgregarCombinacionReceta(elPlatoSeleccionadodelCombo.IDPlato, elIngredienteSeleccionadodelCombo.IDIngrediente, Cantidad);


                MessageBox.Show("Combinacion de Plato/Ingrediente para la receta Agregado!");

                ActualizarListaRecetas();

                LimpiarControles();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void LimpiarControles()
        {
            nudCantidad.Value = 0;
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (dgvRecetas.SelectedRows.Count > 0)
            {
                int IdPlato = int.Parse(dgvRecetas.SelectedRows[0].Cells[0].Value.ToString());
                int IdIngrediente = int.Parse(dgvRecetas.SelectedRows[0].Cells[1].Value.ToString());

                Receta.EliminarCombinacionPlatoIngredienteDeLaReceta(IdPlato, IdIngrediente);

                ActualizarListaRecetas();

                MessageBox.Show("Se ha eliminado el ingrediente de la receta del Plato Correspondiente!");

                LimpiarControles();
            }
            else
                MessageBox.Show("Favor, elija el Plato/ingrediente de la grilla que desea eliminar!");
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            LimpiarControles();
        }
    }
}
