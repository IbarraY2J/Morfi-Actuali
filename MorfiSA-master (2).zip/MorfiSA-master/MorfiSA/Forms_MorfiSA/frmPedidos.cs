﻿using Clases_MorfiSA;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Forms_MorfiSA
{
    public partial class frmPedidos : Form
    {
        public frmPedidos()
        {
            InitializeComponent();
        }

        private void frmPedidos_Load(object sender, EventArgs e)
        {
            ActualizarListaCabeceras();
            cboClientes.DataSource = Cliente.ObtenerListaClientes();
            cboPlatos.DataSource = Plato.ObtenerListaPlatos();
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            
            try
            {

                Cliente elClienteSeleccionadodelCombo = (Cliente)cboClientes.SelectedItem;

                Pedido.GenerarNuevaCabeceraPedido(dtpFecha.Value, elClienteSeleccionadodelCombo.IDCliente);
                
                MessageBox.Show("Se agrego la Cabecera del Pedido, ahora puede agregar el detalle de los Platos y cantidades al mismo!");

                ActualizarListaCabeceras();
                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        
        private void ActualizarListaCabeceras()
        {
            dgvPedidosCabecera.DataSource = null;
            dgvPedidosCabecera.DataSource = Pedido.ObtenerListaCabecerasPedido();
        }

        private void btnAgregarPlatoPedido_Click(object sender, EventArgs e)
        {
            if (dgvPedidosCabecera.SelectedRows.Count > 0)
            {
                int IdPedido = int.Parse(dgvPedidosCabecera.SelectedRows[0].Cells[0].Value.ToString());
                Plato elPlatoSeleccionadodelCombo = (Plato)cboPlatos.SelectedItem;

                DetallePedido.RegistrarDetallePedido(IdPedido, elPlatoSeleccionadodelCombo.IDPlato, int.Parse(nudCantidad.Value.ToString()));

                
                List<Receta> listaIngredientesPorPlato = Receta.ObtenerListaIngredientesPorPlato(elPlatoSeleccionadodelCombo);

                
                foreach (Receta r in listaIngredientesPorPlato)
                {
                    
                    int CantidadADescontar = int.Parse(nudCantidad.Value.ToString()) * r.CantidadNecesariaParaUnPlato;
                    Ingrediente.RestarDelStockActualIngrediente(r.elIngrediente.IDIngrediente, CantidadADescontar);
                }
                                
                ActualizarListaDetalles(IdPedido);

                MessageBox.Show("Detalle del Pedido Registrado y Stock de todos sus Ingredientes tambien Actualizados satisfactoriamente!");
            }
            else
                MessageBox.Show("Debe seleccionar el Pedido de la grilla, a la cual asociar los Platos Pedidos!");
        }

        private void ActualizarListaDetalles(int idPedido)
        {
            dgvPedidosDetalles.DataSource = null;
            dgvPedidosDetalles.DataSource = DetallePedido.ObtenerListaDetallePedido(idPedido);
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (dgvPedidosDetalles.SelectedRows.Count > 0)
            {
                int IdPedido = int.Parse(dgvPedidosDetalles.SelectedRows[0].Cells[0].Value.ToString());
                int IdPlato = int.Parse(dgvPedidosDetalles.SelectedRows[0].Cells[1].Value.ToString());
                int CantidadPedido = int.Parse(dgvPedidosDetalles.SelectedRows[0].Cells[2].Value.ToString());

                
                DetallePedido.EliminarDetallePedido(IdPedido, IdPlato);

                

                ActualizarListaDetalles(IdPedido);

                MessageBox.Show("Se ha eliminado el Plato del Pedido y se actualizo el stock anterior al Pedido!");                
            }
            else
                MessageBox.Show("Favor, elija el Plato del Pedido de la grilla correspondiente que desea eliminar!");
        }
    }
}
