﻿using Clases_MorfiSA;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Forms_MorfiSA
{
    public partial class frmCliente : Form
    {
        public frmCliente()
        {
            InitializeComponent();
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            
            try
            {
                Cliente.AgregarCliente(txtNombre.Text.Trim(), txtNroDocumento.Text.Trim(), txtTelefono.Text.Trim());

                MessageBox.Show("Cliente Agregado!");

                ActualizarListaClientes();

                LimpiarControles();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }            
        }

        private void LimpiarControles()
        {
            txtNombre.Text = string.Empty;
            txtNroDocumento.Text = string.Empty;
            txtTelefono.Text = string.Empty;
            txtNombre.Focus();
        }

        private void btnModificar_Click(object sender, EventArgs e)
        {
            if (lstClientes.SelectedItem != null)
            {
                
                Cliente cli = (Cliente)lstClientes.SelectedItem;
                
                Cliente.ModificarCliente(cli.IDCliente, txtNombre.Text.Trim(), txtNroDocumento.Text.Trim(), txtTelefono.Text.Trim());

                ActualizarListaClientes();

                MessageBox.Show("Cliente Modificado!");

                LimpiarControles();
            }
            else
            {
                MessageBox.Show("Debe seleccionar el Cliente a modificar!");
            }
        }

        private void ActualizarListaClientes()
        {
            lstClientes.DataSource = null;
            lstClientes.DataSource = Cliente.ObtenerListaClientes();
        }

        private void frmCliente_Load(object sender, EventArgs e)
        {
            ActualizarListaClientes();
        }

        private void lstClientes_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstClientes.SelectedItem != null)
            {
                Cliente clienteSeleccionado = (Cliente)lstClientes.SelectedItem;
                txtNombre.Text = clienteSeleccionado.Nombre;
                txtNroDocumento.Text = clienteSeleccionado.NroDocumento;
                txtTelefono.Text = clienteSeleccionado.NroTelefono;
            }
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (lstClientes.SelectedItem != null)
            {
                Cliente clienteSeleccionado = (Cliente)lstClientes.SelectedItem;

                Cliente.EliminarCliente(clienteSeleccionado.IDCliente);

                ActualizarListaClientes();

                MessageBox.Show("Cliente Eliminado!");

                LimpiarControles();
            }
            else
                MessageBox.Show("Favor, elija el cliente de la lista que desea eliminar!");
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            LimpiarControles();
        }
    }
}
