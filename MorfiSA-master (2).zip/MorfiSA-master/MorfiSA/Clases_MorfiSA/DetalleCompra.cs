﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clases_MorfiSA
{
    public class DetalleCompra
    {
        public Compra laCompra { get; set; }
        public Ingrediente elIngrediente { get; set; }
        public int CantidadComprada { get; set; }

        public static void RegistrarDetalleCompra(int idCompra, int iDIngrediente, int CantidadComprada)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(Globales.CadenaConexion))
                {

                    con.Open();

                    string textoCmd = @"insert into DetalleCompra (Compra_ID,IngredienteID, CantidadComprada) 
                                        values (@Compra_ID, @IngredienteID, @CantidadComprada)";

                    SqlCommand cmd = new SqlCommand(textoCmd, con);

                    SqlParameter p1 = new SqlParameter("@Compra_ID", idCompra);
                    p1.SqlDbType = SqlDbType.Int;

                    SqlParameter p2 = new SqlParameter("@IngredienteID", iDIngrediente);
                    p2.SqlDbType = SqlDbType.Int;

                    SqlParameter p3 = new SqlParameter("@CantidadComprada", CantidadComprada);
                    p3.SqlDbType = SqlDbType.Int;

                    cmd.Parameters.Add(p1);
                    cmd.Parameters.Add(p2);
                    cmd.Parameters.Add(p3);
                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static void EliminarDetalleCompra(int idCompra, int idIngrediente)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(Globales.CadenaConexion))
                {

                    con.Open();

                    string textoCmd = @"Delete from DetalleCompra where Compra_ID = @Compra_ID and IngredienteID = @IngredienteID";

                    SqlCommand cmd = new SqlCommand(textoCmd, con);

                    SqlParameter p1 = new SqlParameter("@Compra_ID", idCompra);
                    p1.SqlDbType = SqlDbType.Int;

                    SqlParameter p2 = new SqlParameter("@IngredienteID", idIngrediente);
                    p2.SqlDbType = SqlDbType.Int;

                    cmd.Parameters.Add(p1);
                    cmd.Parameters.Add(p2);

                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static DataTable ObtenerListaDetalleCompra(int IdCompra)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(Globales.CadenaConexion))
                {
                    con.Open();

                    string textoCmd = "SELECT * from DetalleCompra where Compra_ID = @CompraID";

                    SqlParameter p1 = new SqlParameter("@CompraID", IdCompra);
                    p1.SqlDbType = SqlDbType.Int;
                    
                    DataTable datos = new DataTable();

                    SqlCommand cmd = new SqlCommand(textoCmd, con);
                    cmd.Parameters.Add(p1);

                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    adapter.Fill(datos);

                    return datos;
                }
            }
            catch (Exception ex2)
            {
                throw ex2;
            }
        }
    }
}
