﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clases_MorfiSA
{
    public class Cliente
    {
       public int IDCliente { get; set; }
       public string Nombre { get; set; }
       public string NroDocumento { get; set; }
       public string NroTelefono { get; set; }

        public override string ToString()
        {
            return Nombre;
        }

        public static void AgregarCliente(string pNombre, string pNroDocumento, string pNroTelefono)
        {
            try
            {                
                using (SqlConnection con = new SqlConnection(Globales.CadenaConexion))
                {
                    
                    con.Open();

                    string textoCmd = @"insert into Cliente (Nombre, NroDocumento, Telefono) 
                                        values (@Nombre, @NroDocumento, @Telefono)";

                    SqlCommand cmd = new SqlCommand(textoCmd, con);

                    SqlParameter p1 = new SqlParameter("@Nombre", pNombre);
                    p1.SqlDbType = SqlDbType.VarChar;

                    SqlParameter p2 = new SqlParameter("@NroDocumento", pNroDocumento);
                    p2.SqlDbType = SqlDbType.VarChar;

                    SqlParameter p3 = new SqlParameter("@Telefono", pNroTelefono);
                    p3.SqlDbType = SqlDbType.VarChar;                    

                    cmd.Parameters.Add(p1);
                    cmd.Parameters.Add(p2);
                    cmd.Parameters.Add(p3);
                                        
                    cmd.ExecuteNonQuery();                    
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static void ModificarCliente(int pIDCliente,string pNombre, string pNroDocumento, string pNroTelefono)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(Globales.CadenaConexion))
                {

                    con.Open();

                    string textoCmd = @"update Cliente set Nombre =@Nombre, NroDocumento =@NroDocumento, Telefono=@Telefono where ID_Cliente = @IDCliente";

                    SqlCommand cmd = new SqlCommand(textoCmd, con);

                    SqlParameter p1 = new SqlParameter("@Nombre", pNombre);
                    p1.SqlDbType = SqlDbType.VarChar;

                    SqlParameter p2 = new SqlParameter("@NroDocumento", pNroDocumento);
                    p2.SqlDbType = SqlDbType.VarChar;

                    SqlParameter p3 = new SqlParameter("@Telefono", pNroTelefono);
                    p3.SqlDbType = SqlDbType.VarChar;

                    SqlParameter p4 = new SqlParameter("@IDCliente", pIDCliente);
                    p4.SqlDbType = SqlDbType.Int;


                    cmd.Parameters.Add(p1);
                    cmd.Parameters.Add(p2);
                    cmd.Parameters.Add(p3);
                    cmd.Parameters.Add(p4);

                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static void EliminarCliente(int pIDCliente)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(Globales.CadenaConexion))
                {

                    con.Open();

                    string textoCmd = @"Delete from Cliente where ID_Cliente = @IDCliente";

                    SqlCommand cmd = new SqlCommand(textoCmd, con);
                    
                    SqlParameter p1 = new SqlParameter("@IDCliente", pIDCliente);
                    p1.SqlDbType = SqlDbType.Int;                    
                    cmd.Parameters.Add(p1);

                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static List<Cliente> ObtenerListaClientes()
        {
            List<Cliente> listaDeTodosLosClientes = new List<Cliente>();
            Cliente cli;

            try
            {
                using (SqlConnection con = new SqlConnection(Globales.CadenaConexion))
                {

                    con.Open();

                    string textoCmd = @"select * from Cliente";

                    SqlCommand cmd = new SqlCommand(textoCmd, con);

                    SqlDataReader elLectorDeDatos = cmd.ExecuteReader();

                    while (elLectorDeDatos.Read())
                    {
                        cli = new Cliente();
                        cli.IDCliente = elLectorDeDatos.GetInt32(0);
                        cli.Nombre = elLectorDeDatos.GetString(1);
                        cli.NroDocumento = elLectorDeDatos.GetString(2);
                        cli.NroTelefono = elLectorDeDatos.GetString(3);                        
                        listaDeTodosLosClientes.Add(cli);
                    }

                    return listaDeTodosLosClientes;
                }
            }
            catch (Exception ex)
            {
                throw ex;                
            }
        }
    }
}
