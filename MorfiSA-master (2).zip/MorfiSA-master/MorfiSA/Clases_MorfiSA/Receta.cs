﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clases_MorfiSA
{
    public class Receta
    {
        public Plato elPlato { get; set; }
        public Ingrediente elIngrediente { get; set; }
        public int CantidadNecesariaParaUnPlato { get; set; }

        public static DataTable ObtenerListaRecetas()
        {
            try
            {
                using (SqlConnection con = new SqlConnection(Globales.CadenaConexion))
                {                    
                    con.Open();

                    string textoCmd = "SELECT * from Receta";

                    DataTable datos = new DataTable();

                    SqlCommand cmd = new SqlCommand(textoCmd, con);

                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    adapter.Fill(datos);

                    return datos;
                }
            }
            catch (Exception ex2)
            {
                throw ex2;
            }
        }

        public static List<Receta> ObtenerListaIngredientesPorPlato(Plato pPlato)
        {
            List<Receta> listaDeIngredientesPorPlato = new List<Receta>();
            Receta CombinacionPlatoIngrediente;
            Ingrediente ingredienteDelPlato;

            try
            {
                using (SqlConnection con = new SqlConnection(Globales.CadenaConexion))
                {
                    con.Open();

                    string textoCmd = @"SELECT Ingrediente_ID, 
                                               Nombre, 
                                               CantidadExistencia,
                                               CantidadNecesariaParaUnaPorcion                                                
                                        FROM Receta R
                                        join Ingrediente I on R.Ingrediente_ID = I.ID_Ingrediente
                                        where Plato_ID = @PlatoID";

                    

                    SqlCommand cmd = new SqlCommand(textoCmd, con);

                    SqlParameter p1 = new SqlParameter("@PlatoID", pPlato.IDPlato);
                    p1.SqlDbType = SqlDbType.Int;

                    cmd.Parameters.Add(p1);

                    SqlDataReader elLectorDeDatos = cmd.ExecuteReader();

                    while (elLectorDeDatos.Read())
                    {
                        CombinacionPlatoIngrediente = new Receta();

                        //Leemos los ingredientes del Plato especifico. Por lo tanto, como recibimos como parametro el Plato en si, le asignamos al objeto Receta.
                        CombinacionPlatoIngrediente.elPlato = pPlato;

                        //Creamos el ingrediente con lo que leemos de la base de datos:

                        ingredienteDelPlato = new Ingrediente();
                        ingredienteDelPlato.IDIngrediente = elLectorDeDatos.GetInt32(0);
                        ingredienteDelPlato.Nombre = elLectorDeDatos.GetString(1);
                        ingredienteDelPlato.CantidadExistencia = elLectorDeDatos.GetInt32(2);

                        //Asignamos al objeto Receta, el ingrediente
                        CombinacionPlatoIngrediente.elIngrediente = ingredienteDelPlato;

                        //Esta el Plato (el mismo siempre, que recibimos como parametro), los ingredientes que tomamos de la Receta de la BD y finalmente la cantidad necesaria para elaborar 1 porcion (tambien de la tabla Receta)
                        CombinacionPlatoIngrediente.CantidadNecesariaParaUnPlato = elLectorDeDatos.GetInt32(3);
                        
                        listaDeIngredientesPorPlato.Add(CombinacionPlatoIngrediente);
                    }

                    return listaDeIngredientesPorPlato;
                }
            }
            catch (Exception ex2)
            {
                throw ex2;
            }
        }

        public static void AgregarCombinacionReceta(int iDPlato, int iDIngrediente, int cantidad)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(Globales.CadenaConexion))
                {

                    con.Open();

                    string textoCmd = @"insert into Receta (Plato_ID,Ingrediente_ID, CantidadNecesariaParaUnaPorcion) 
                                        values (@Plato_ID, @Ingrediente_ID, @CantidadNecesariaParaUnaPorcion)";

                    SqlCommand cmd = new SqlCommand(textoCmd, con);

                    SqlParameter p1 = new SqlParameter("@Plato_ID", iDPlato);
                    p1.SqlDbType = SqlDbType.Int;

                    SqlParameter p2 = new SqlParameter("@Ingrediente_ID", iDIngrediente);
                    p2.SqlDbType = SqlDbType.Int;

                    SqlParameter p3 = new SqlParameter("@CantidadNecesariaParaUnaPorcion", cantidad);
                    p3.SqlDbType = SqlDbType.Int;



                    cmd.Parameters.Add(p1);
                    cmd.Parameters.Add(p2);
                    cmd.Parameters.Add(p3);
                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static void EliminarCombinacionPlatoIngredienteDeLaReceta(int idPlato, int idIngrediente)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(Globales.CadenaConexion))
                {

                    con.Open();

                    string textoCmd = @"Delete from Receta where Plato_ID = @Plato_ID and Ingrediente_ID = @IngredienteID";

                    SqlCommand cmd = new SqlCommand(textoCmd, con);

                    SqlParameter p1 = new SqlParameter("@Plato_ID", idPlato);
                    p1.SqlDbType = SqlDbType.Int;

                    SqlParameter p2 = new SqlParameter("@IngredienteID", idIngrediente);
                    p2.SqlDbType = SqlDbType.Int;
                    cmd.Parameters.Add(p1);
                    cmd.Parameters.Add(p2);

                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
