﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clases_MorfiSA
{
    public class Ingrediente
    {
        public int IDIngrediente { get; set; }
        public string Nombre { get; set; }
        public int CantidadExistencia { get; set; }

        public override string ToString()
        {
            return Nombre;
        }

        public static List<Ingrediente> ObtenerListaIngredientes()
        {
            List<Ingrediente> listaDeTodosLosIngredientes = new List<Ingrediente>();
            Ingrediente Ing;

            try
            {
                using (SqlConnection con = new SqlConnection(Globales.CadenaConexion))
                {

                    con.Open();

                    string textoCmd = @"select * from Ingrediente";

                    SqlCommand cmd = new SqlCommand(textoCmd, con);

                    SqlDataReader elLectorDeDatos = cmd.ExecuteReader();

                    while (elLectorDeDatos.Read())
                    {
                        Ing = new Ingrediente();
                        Ing.IDIngrediente = elLectorDeDatos.GetInt32(0);
                        Ing.Nombre = elLectorDeDatos.GetString(1);
                        Ing.CantidadExistencia = elLectorDeDatos.GetInt32(2);

                        listaDeTodosLosIngredientes.Add(Ing);
                    }

                    return listaDeTodosLosIngredientes;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static void AgregarIngrediente(string pNombreIngrediente)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(Globales.CadenaConexion))
                {

                    con.Open();

                    string textoCmd = @"insert into Ingrediente (Nombre,CantidadExistencia) 
                                        values (@Nombre, @CantidadExistencia)";

                    SqlCommand cmd = new SqlCommand(textoCmd, con);

                    SqlParameter p1 = new SqlParameter("@Nombre", pNombreIngrediente);
                    p1.SqlDbType = SqlDbType.VarChar;

                    //Al crear, creamos con existencia 0. Solo con las compras y pedidos actualizamos el stock.
                    int CantidadExistencia = 0;
                    SqlParameter p2 = new SqlParameter("@CantidadExistencia", CantidadExistencia); 
                    p2.SqlDbType = SqlDbType.Int;

                    cmd.Parameters.Add(p1);
                    cmd.Parameters.Add(p2);
                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static void ActualizarStock(int iDIngrediente, int existenciaActualizadaPostCompra)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(Globales.CadenaConexion))
                {

                    con.Open();

                    string textoCmd = @"update Ingrediente set CantidadExistencia = @Cantidad 
                                        where ID_Ingrediente = @IdIngrediente";

                    SqlCommand cmd = new SqlCommand(textoCmd, con);

                    SqlParameter p1 = new SqlParameter("@IdIngrediente", iDIngrediente);
                    p1.SqlDbType = SqlDbType.Int;

                    SqlParameter p2 = new SqlParameter("@Cantidad", existenciaActualizadaPostCompra);
                    p2.SqlDbType = SqlDbType.Int;
                   
                    cmd.Parameters.Add(p1);
                    cmd.Parameters.Add(p2);
                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static void RestarDelStockActualIngrediente(int idIngrediente, int cantidad)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(Globales.CadenaConexion))
                {

                    con.Open();

                    string textoCmd = @"update Ingrediente set CantidadExistencia = CantidadExistencia - @Cantidad 
                                        where ID_Ingrediente = @IdIngrediente";

                    SqlCommand cmd = new SqlCommand(textoCmd, con);

                    SqlParameter p1 = new SqlParameter("@IdIngrediente", idIngrediente);
                    p1.SqlDbType = SqlDbType.Int;

                    SqlParameter p2 = new SqlParameter("@Cantidad", cantidad);
                    p2.SqlDbType = SqlDbType.Int;

                    cmd.Parameters.Add(p1);
                    cmd.Parameters.Add(p2);
                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static void EliminarIngrediente(int iDIngrediente)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(Globales.CadenaConexion))
                {

                    con.Open();

                    string textoCmd = @"Delete from Ingrediente where ID_Ingrediente = @IngredienteID";

                    SqlCommand cmd = new SqlCommand(textoCmd, con);

                    SqlParameter p1 = new SqlParameter("@IngredienteID", iDIngrediente);
                    p1.SqlDbType = SqlDbType.Int;
                    cmd.Parameters.Add(p1);

                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static void ModificarPlato(int iDPlato, string nombrePlato)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(Globales.CadenaConexion))
                {

                    con.Open();

                    string textoCmd = @"update Ingrediente set Nombre= @Nombre where ID_Ingrediente = @ID_Ingrediente";

                    SqlCommand cmd = new SqlCommand(textoCmd, con);

                    SqlParameter p1 = new SqlParameter("@Nombre", nombrePlato);
                    p1.SqlDbType = SqlDbType.VarChar;

                    SqlParameter p2 = new SqlParameter("@ID_Ingrediente", iDPlato);
                    p2.SqlDbType = SqlDbType.Int;

                    cmd.Parameters.Add(p1);
                    cmd.Parameters.Add(p2);

                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
