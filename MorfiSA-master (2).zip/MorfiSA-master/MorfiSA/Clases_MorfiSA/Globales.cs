﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clases_MorfiSA
{
    public class Globales
    {
        public static string CadenaConexion = "Data Source = M202-21; Initial Catalog = Morfi; User ID=sa; Password = @lumno123";
    }
}
