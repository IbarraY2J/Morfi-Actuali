﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clases_MorfiSA
{
    public class CalculoIngrediente
    {
        public string NombreIngrediente { get; set; }
        public int CantidadExistencia { get; set; }
        public int CantidadNecesaria { get; set; }
        public int Diferencia { get; set; }
    }
}
