﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clases_MorfiSA
{
    public class Pedido
    {
        public int IDPedido { get; set; }
        public DateTime FechaPedido { get; set; }
        public Cliente elCliente { get; set; }

        public static void GenerarNuevaCabeceraPedido(DateTime Fecha, int iDCliente)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(Globales.CadenaConexion))
                {

                    con.Open();

                    string textoCmd = @"insert into Pedido (FechaPedido, Cliente_ID) 
                                        values (@Fecha, @Cliente_ID)";

                    SqlCommand cmd = new SqlCommand(textoCmd, con);

                    SqlParameter p1 = new SqlParameter("@Fecha", Fecha);
                    p1.SqlDbType = SqlDbType.DateTime;

                    SqlParameter p2 = new SqlParameter("@Cliente_ID", iDCliente);
                    p2.SqlDbType = SqlDbType.Int;

                    cmd.Parameters.Add(p1);
                    cmd.Parameters.Add(p2);

                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static DataTable ObtenerListaCabecerasPedido()
        {
            try
            {
                using (SqlConnection con = new SqlConnection(Globales.CadenaConexion))
                {
                    con.Open();

                    string textoCmd = "SELECT * from Pedido";

                    DataTable datos = new DataTable();

                    SqlCommand cmd = new SqlCommand(textoCmd, con);

                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    adapter.Fill(datos);

                    return datos;
                }
            }
            catch (Exception ex2)
            {
                throw ex2;
            }
        }
    }
}
