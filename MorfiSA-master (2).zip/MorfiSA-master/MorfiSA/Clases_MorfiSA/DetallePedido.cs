﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clases_MorfiSA
{
    public class DetallePedido
    {
        public Pedido elPedido { get; set; }
        public Plato elPlato { get; set; }
        public int CantidadPedido { get; set; }

        public static void RegistrarDetallePedido(int idPedido, int iDPlato, int CantidadPedido)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(Globales.CadenaConexion))
                {

                    con.Open();

                    string textoCmd = @"insert into DetallePedido (Pedido_ID,Plato_ID, CantidadPedido) 
                                        values (@Pedido_ID, @Plato_ID, @CantidadPedido)";

                    SqlCommand cmd = new SqlCommand(textoCmd, con);

                    SqlParameter p1 = new SqlParameter("@Pedido_ID", idPedido);
                    p1.SqlDbType = SqlDbType.Int;

                    SqlParameter p2 = new SqlParameter("@Plato_ID", iDPlato);
                    p2.SqlDbType = SqlDbType.Int;

                    SqlParameter p3 = new SqlParameter("@CantidadPedido", CantidadPedido);
                    p3.SqlDbType = SqlDbType.Int;

                    cmd.Parameters.Add(p1);
                    cmd.Parameters.Add(p2);
                    cmd.Parameters.Add(p3);
                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static object ObtenerListaDetallePedido(int idPedido)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(Globales.CadenaConexion))
                {
                    con.Open();

                    string textoCmd = "SELECT * from DetallePedido where Pedido_ID = @Pedido_ID";

                    SqlParameter p1 = new SqlParameter("@Pedido_ID", idPedido);
                    p1.SqlDbType = SqlDbType.Int;

                    DataTable datos = new DataTable();

                    SqlCommand cmd = new SqlCommand(textoCmd, con);
                    cmd.Parameters.Add(p1);

                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    adapter.Fill(datos);

                    return datos;
                }
            }
            catch (Exception ex2)
            {
                throw ex2;
            }
        }

        public static void EliminarDetallePedido(int idPedido, int idPlato)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(Globales.CadenaConexion))
                {

                    con.Open();

                    string textoCmd = @"Delete from DetallePedido where Pedido_ID = @Pedido_ID and Plato_ID = @Plato_ID";

                    SqlCommand cmd = new SqlCommand(textoCmd, con);

                    SqlParameter p1 = new SqlParameter("@Pedido_ID", idPedido);
                    p1.SqlDbType = SqlDbType.Int;

                    SqlParameter p2 = new SqlParameter("@Plato_ID", idPlato);
                    p2.SqlDbType = SqlDbType.Int;

                    cmd.Parameters.Add(p1);
                    cmd.Parameters.Add(p2);

                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
