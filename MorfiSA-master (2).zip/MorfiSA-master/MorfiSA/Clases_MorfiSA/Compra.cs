﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clases_MorfiSA
{
    public class Compra
    {
        public int IDCompra { get; set; }
        public DateTime FechaCompra { get; set; }
        public string NroFacturaOComprobante { get; set; }

        public static DataTable ObtenerListaCabecerasCompra()
        {
            try
            {
                using (SqlConnection con = new SqlConnection(Globales.CadenaConexion))
                {
                    con.Open();

                    string textoCmd = "SELECT * from Compra";

                    DataTable datos = new DataTable();

                    SqlCommand cmd = new SqlCommand(textoCmd, con);

                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    adapter.Fill(datos);

                    return datos;
                }
            }
            catch (Exception ex2)
            {
                throw ex2;
            }
        }

        public static void GenerarNuevaCompra(DateTime fechaFactura, string NroFacturaOComprobante)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(Globales.CadenaConexion))
                {

                    con.Open();

                    string textoCmd = @"insert into Compra (Fecha, FacturaOComprobante) 
                                        values (@Fecha, @FacturaOComprobante)";

                    SqlCommand cmd = new SqlCommand(textoCmd, con);

                    SqlParameter p1 = new SqlParameter("@Fecha", fechaFactura);
                    p1.SqlDbType = SqlDbType.DateTime;

                    SqlParameter p2 = new SqlParameter("@FacturaOComprobante", NroFacturaOComprobante);
                    p2.SqlDbType = SqlDbType.VarChar;

                    cmd.Parameters.Add(p1);
                    cmd.Parameters.Add(p2);

                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
