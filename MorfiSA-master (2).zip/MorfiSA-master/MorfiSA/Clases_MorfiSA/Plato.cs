﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clases_MorfiSA
{
    public class Plato
    {
        public int IDPlato { get; set; }
        public string NombrePlato { get; set; }

        public override string ToString()
        {
            return NombrePlato;
        }

        public static void AgregarPlato(string pNombrePlato)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(Globales.CadenaConexion))
                {

                    con.Open();

                    string textoCmd = @"insert into Plato (Nombre) 
                                        values (@Nombre)";

                    SqlCommand cmd = new SqlCommand(textoCmd, con);

                    SqlParameter p1 = new SqlParameter("@Nombre", pNombrePlato);
                    p1.SqlDbType = SqlDbType.VarChar;
                    
                    cmd.Parameters.Add(p1);                    
                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static void ModificarPlato(int pIDPlato, string pNombrePlato)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(Globales.CadenaConexion))
                {

                    con.Open();

                    string textoCmd = @"update Plato set Nombre= @Nombre where ID_Plato = @ID_Plato";

                    SqlCommand cmd = new SqlCommand(textoCmd, con);

                    SqlParameter p1 = new SqlParameter("@Nombre", pNombrePlato);
                    p1.SqlDbType = SqlDbType.VarChar;

                    SqlParameter p2 = new SqlParameter("@ID_Plato", pIDPlato);
                    p2.SqlDbType = SqlDbType.Int;
                                                            
                    cmd.Parameters.Add(p1);
                    cmd.Parameters.Add(p2);
                    
                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static void EliminarPlato(int pIDPlato)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(Globales.CadenaConexion))
                {

                    con.Open();

                    string textoCmd = @"Delete from Plato where ID_Plato = @PlatoID";

                    SqlCommand cmd = new SqlCommand(textoCmd, con);

                    SqlParameter p1 = new SqlParameter("@PlatoID", pIDPlato);
                    p1.SqlDbType = SqlDbType.Int;
                    cmd.Parameters.Add(p1);

                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static List<Plato> ObtenerListaPlatos()
        {
            List<Plato> listaDeTodosLosPlatos = new List<Plato>();
            Plato p;

            try
            {
                using (SqlConnection con = new SqlConnection(Globales.CadenaConexion))
                {

                    con.Open();

                    string textoCmd = @"select * from Plato";

                    SqlCommand cmd = new SqlCommand(textoCmd, con);

                    SqlDataReader elLectorDeDatos = cmd.ExecuteReader();

                    while (elLectorDeDatos.Read())
                    {
                        p = new Plato();
                        p.IDPlato = elLectorDeDatos.GetInt32(0);                        
                        p.NombrePlato = elLectorDeDatos.GetString(1);

                        listaDeTodosLosPlatos.Add(p);
                    }

                    return listaDeTodosLosPlatos;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
